**Data downloaded from [NRFA](https://nrfa.ceh.ac.uk/data/search)**

`HGHT_SEVERN_1km.tif` is a file that has been subset using QGIS with clip and gdal warp functions. 